#' @name Sens.MCPARD
#' @title Teste de Ordenação - Método de Christensen
#' @author Gabriel Sartori e Jhenifer Caetano Veloso
#' @export
#'
#' @description Calcula o teste de ordenação de christensen com base no 
#' forncimento dos avaliadores, produtos e rankeamento.
#' 
#' @param judge, Vetor fator que identifica os avaliadores
#' @param trt, Vetor fator que identifica os tratamentos (produtos)
#' @param evaluation, Vetor numérico que identifica as notas dos respectivos 
#' produtos com os avaliadores
#' @param alpha, Valor de significância, Escolher entre (0.1, 0.05 ou 0.01)
#'
#' @return Verifica se há ou não diferenças nos rankings entre as amostras
#' 
#' @examples
#' 
#' require(agricolae)
#' 
#' judge <- rep(1:10, each = 3)
#' trt <- rep(1:3, 10)
#' evaluation <- rep(1:3, 10)
#' alpha <- 0.05
#' Sens.MCPARD(judge, trt, evaluation, alpha)
Sens.MCPARD <- function(judge, trt, evaluation, alpha){
  require(agricolae)
  dados <- data.frame(judge, trt, evaluation)
  
  # Transformando os dados
  judge <- as.factor(judge) # Avaliador
  trt <- as.factor(trt) # Produtos
  evaluation <- as.integer(evaluation) # Posição
  
  
  # Levels dos dados
  l.j <- length(levels(judge)) # Quantas Avaliadores
  l.t <- length(levels(trt)) # Quantas Amostras
  
  # Calcular a amplitude dos dados
  sum.amos <- with(dados, # Somando todos as posições por produtos
                   tapply(evaluation, trt, sum)) 
  
  md <- max(sum.amos) - min(sum.amos)
  
  # Setando o alpha = 0.01
  # Critical Value Global (Maximun Distance Between Samples)
  # Critical Value Local (Multiple Comparison)
  
  if(alpha == 0.01){
    if(l.t == 3) {
      cv.g <- 4.0167*(l.j^0.5046)
      cv.l <- 3.6057*(l.j^0.5014)
    }
    if(l.t == 4){
      cv.g <- 5.6278*(l.j^0.5018)
      cv.l <- 4.5684*(l.j^0.5064)
    }
    if(l.t == 5){
      cv.g <- 6.7912*(l.j^0.5085)
      cv.l <- 5.6658*(l.j^0.5030)
    }
    if(l.t == 6){
      cv.g <- 8.6236*(l.j^0.5064)
      cv.l <- 6.6047*(l.j^0.5067)
    }
    if(l.t == 7){
      cv.g <- 10.099*(l.j^0.5089)
      cv.l <- 7.7675*(l.j^0.5026)
    }
    if(l.t == 8){
      cv.g <- 11.809*(l.j^0.5071)
      cv.l <- 8.8169*(l.j^0.5022)
    }
    if(l.t == 9){
      cv.g <- 13.281*(l.j^0.5098)
      cv.l <- 9.7451*(l.j^0.5049)
    }
    if(l.t == 10){
      cv.g <- 14.976*(l.j^0.5084)
      cv.l <- 10.8968*(l.j^0.5022)
    }
    if(l.t == 11){
      cv.g <- 16.800*(l.t^0.5061)
      cv.l <- 11.8418*(l.j^0.5042)
    }
    if(l.t == 12){
      cv.g <- 18.281*(l.j^0.5088)
      cv.l <- 13.0501*(l.j^0.5009)
    }
  } 
  # Alpha 0.05
  if(alpha == 0.05) {
    if(l.t == 3) {
      cv.g <- 3.2236*(l.j^0.5055)
      cv.l <- 2.7113*(l.j^0.5048)
    }
    if(l.t == 4){
      cv.g <- 4.5497*(l.j^0.5070)
      cv.l <- 3.5594*(l.j^0.5015)
    }
    if(l.t == 5){
      cv.g <- 5.7700*(l.j^0.5033)
      cv.l <- 4.3553*(l.j^0.5012)
    }
    if(l.t == 6){
      cv.g <- 7.2948*(l.j^0.5070)
      cv.l <- 5.1154*(l.j^0.5031)
    }
    if(l.t == 7){
      cv.g <- 8.8072 * (l.j^0.5045)
      cv.l <- 5.9529*(l.j^0.5010)
    }
    if(l.t == 8){
      cv.g <- 10.214*(l.j^0.5059)
      cv.l <- 6.7103*(l.j^0.5026)
    }
    if(l.t == 9){
      cv.g <- 11.710*(l.j^0.5053)
      cv.l <- 7.5625*(l.j^0.5008)
    }
    if(l.t == 10){
      cv.g <- 13.310*(l.j^0.5032)
      cv.l <- 8.3191*(l.j^0.5017)
    }
    if(l.t == 11){
      cv.g <- 14.813*(l.j^0.5036)
      cv.l <- 9.1455*(l.j^0.5009)
    }
    if(l.t == 12){
      cv.g <- 16.262*(l.j^0.5050)
      cv.l <- 10.0585*(l.j^0.4984)
    }
  }
  # Alpha = 0.10
  if(alpha == 0.10) {
    if(l.t == 3) {
      cv.g <- 2.8767*(l.j^0.5016)
      cv.l <- 2.3069*(l.j^0.5016)
    }
    if(l.t == 4){
      cv.g <- 4.0848*(l.j^0.5059)
      cv.l <- 2.9371*(l.j^0.5054)
    }
    if(l.t == 5){
      cv.g <- 5.2254*(l.j^0.5013)
      cv.l <- 3.6582*(l.j^0.5011)
    }
    if(l.t == 6){
      cv.g <- 6.7365*(l.j^0.5037)
      cv.l <- 4.3261*(l.j^0.5014)
    }
    if(l.t == 7){
      cv.g <- 8.1333 * (l.j^0.5024)
      cv.l <- 5.0347*(l.j^0.4998)
    }
    if(l.t == 8){
      cv.g <- 9.5141*(l.j^0.5024)
      cv.l <- 5.7220*(l.j^0.4991)
    }
    if(l.t == 9){
      cv.g <- 10.901*(l.j^0.5028)
      cv.l <- 6.3868*(l.j^0.4996)
    }
    if(l.t == 10){
      cv.g <- 12.324*(l.j^0.5028)
      cv.l <- 7.0037*(l.j^0.5011)
    }
    if(l.t == 11){
      cv.g <- 13.777*(l.j^0.5026)
      cv.l <- 7.6977*(l.j^0.5005)
    }
    if(l.t >= 12){
      cv.g <- 15.244*(l.j^0.5025)
      cv.l <- 8.3557*(l.j^0.5010)
    }
  }
  sa <- as.data.frame(sum.amos)
  # Comparação da Amplitude e Ponto de Corte
  if(md <= cv.g) { 
    cat("\nGroupTreatment and Sum of the ranks\n")
    for(i in 1:l.t){
      cat(rownames(sa)[i], "\t", 
          sa$sum.amos[i], "\n")
    }
    cat("\nMaximum distance between samples : ", md)
    cat("\nAlpha : ", alpha)
    cat("\nCritical Value (CV) : ", cv.g)
    cat("\nNS (Not Significance) between samples")
  } else {
    groups <- order.stat(levels(trt), # Nome dos Produtos
                         sum.amos, # Diferença dos produtos
                         cv.l, # Corte Mínimo
                         console = FALSE)
    cat("\nGroupTreatment and Sum of the ranks\n")
    for(i in 1: l.t){
      cat(rownames(sa)[i], "\t", 
          sa$sum.amos[i], "\n")
    }
    cat("\nMaximum distance between samples : ", md)
    cat("\nAlpha : ", alpha)
    cat("\nCritical Value :", cv.g)
    cat("\n\nMultiple Comparisons \n ")
    cat("================== \n ")
    
    M <- groups$M
    trat <- groups$trt
    
    cat("\nAlpha : ", alpha)
    cat("\nCritical Value : ", round(cv.l,2))
    cat("\n\nSums with the same letter are not significantly different")
    cat("\nGroupTreatment and Sum of the ranks\n")
    for(i in 1:l.t){
      cat(as.character(M[i]), "\t", 
          as.character(trat[i]), "\t", 
          groups$means[i], "\n")
    }
  }
}

