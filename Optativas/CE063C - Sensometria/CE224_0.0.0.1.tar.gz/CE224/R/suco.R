#' @name suco
#' @title Rankeamento de Suco de Laranja
#' @author Gabriel Sartori e Jhenifer Caetano Veloso
#' @description Rankeamento da doçura de sucos de laranja de 4 diferentes marcas, 
#' dados obtidos durante as aulas experimentais da disciplina de Sensometria.
#' 
#' @format Um \code{data.frame} com 68 observações e 3 variáveis
#'
#' \describe{
#'
#' \item{\code{avaliador}}{Vetor fator que identifica os avaliadores}
#'
#' \item{\code{produto}}{Vetor fator que identifica os produtos}
#'     
#' \item{\code{posicao}}{Vetor numérico que identifica os ranks dos respectivos 
#' produtos avaliados}
#' }
#' 
#' @examples
#' 
#' require(agricolae)
#' str(suco)
#' Sens.MCPARD(suco$avaliador, suco$produto, suco$posicao, alpha = 0.05)
NULL